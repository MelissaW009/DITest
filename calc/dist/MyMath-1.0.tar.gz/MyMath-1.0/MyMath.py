# coding:utf-8
import sys

class MyMath(object):

    # 判断是否为数字
    @classmethod
    def isNum( cls,value):
        try:
            value + 1
        except TypeError:
            return False
        else:
            return True

    # 判断是否为数字
    @classmethod
    def isNum2(cls, value):
        try:
            x = int(value)
        except TypeError:
            return False
        except ValueError:
            return False
        except Exception:
            return False
        else:
            return True

if __name__ == '__main__':
    a = MyMath()
    a.isNum(1)