

from distutils.core import setup
setup(name='MyMath',
      version='1.0',
      description='My Math Utilities',
      author='Melissa',
      author_email='',
      url='',
      py_modules=['MyMath'],
      )  